<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
    <meta name="description" content="Page Title">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no, minimal-ui">
    <!-- Call App Mode on ios devices -->
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <!-- Remove Tap Highlight on Windows Phone IE -->
    <meta name="msapplication-tap-highlight" content="no">

    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets')); ?>/css/vendors.bundle.css">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets')); ?>/css/app.bundle.css">
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('backend/assets')); ?>/img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('backend/assets')); ?>/img/favicon/favicon-32x32.png">
    <link rel="mask-icon" href="<?php echo e(asset('backend/assets')); ?>/img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets')); ?>/css/miscellaneous/reactions/reactions.css">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets')); ?>/css/miscellaneous/fullcalendar/fullcalendar.bundle.css">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets')); ?>/css/miscellaneous/jqvmap/jqvmap.bundle.css">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets')); ?>/css/notifications/sweetalert2/sweetalert2.bundle.css">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets')); ?>/css/datagrid/datatables/datatables.bundle.css">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets')); ?>/css/formplugins/select2/select2.bundle.css">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets')); ?>/css/formplugins/summernote/summernote.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <style>
        .tox-promotion {
            display: none !important;
        }
        .tox-statusbar__right-container {
            display: none !important;
        }
    </style>
    <?php if (isset($component)) { $__componentOriginal1d4b7b638da2b942f8d890c5be44931b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1d4b7b638da2b942f8d890c5be44931b = $attributes; } ?>
<?php $component = App\View\Components\Head\TextEditorConfig::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('head.text-editor-config'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Head\TextEditorConfig::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1d4b7b638da2b942f8d890c5be44931b)): ?>
<?php $attributes = $__attributesOriginal1d4b7b638da2b942f8d890c5be44931b; ?>
<?php unset($__attributesOriginal1d4b7b638da2b942f8d890c5be44931b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1d4b7b638da2b942f8d890c5be44931b)): ?>
<?php $component = $__componentOriginal1d4b7b638da2b942f8d890c5be44931b; ?>
<?php unset($__componentOriginal1d4b7b638da2b942f8d890c5be44931b); ?>
<?php endif; ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<!-- BEGIN Body -->

<body class="mod-bg-1 ">
<!-- DOC: script to save and load page settings -->
<script>
    /**
     *	This script should be placed right after the body tag for fast execution
     *	Note: the script is written in pure javascript and does not depend on thirdparty library
     **/
    'use strict';

    var classHolder = document.getElementsByTagName("BODY")[0],
        /**
         * Load from localstorage
         **/
        themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) :
            {},
        themeURL = themeSettings.themeURL || '',
        themeOptions = themeSettings.themeOptions || '';
    /**
     * Load theme options
     **/
    if (themeSettings.themeOptions)
    {
        classHolder.className = themeSettings.themeOptions;
        console.log("%c✔ Theme settings loaded", "color: #148f32");
    }
    else
    {
        console.log("%c✔ Heads up! Theme settings is empty or does not exist, loading default settings...", "color: #ed1c24");
    }
    if (themeSettings.themeURL && !document.getElementById('mytheme'))
    {
        var cssfile = document.createElement('link');
        cssfile.id = 'mytheme';
        cssfile.rel = 'stylesheet';
        cssfile.href = themeURL;
        document.getElementsByTagName('head')[0].appendChild(cssfile);

    }
    else if (themeSettings.themeURL && document.getElementById('mytheme'))
    {
        document.getElementById('mytheme').href = themeSettings.themeURL;
    }
    /**
     * Save to localstorage
     **/
    var saveSettings = function()
    {
        themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function(item)
        {
            return /^(nav|header|footer|mod|display)-/i.test(item);
        }).join(' ');
        if (document.getElementById('mytheme'))
        {
            themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
        };
        localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
    }
    /**
     * Reset settings
     **/
    var resetSettings = function()
    {
        localStorage.setItem("themeSettings", "");
    }

</script>
<!-- BEGIN Page Wrapper -->
<div class="page-wrapper">
    <div class="page-inner">
        <!-- BEGIN Left Aside -->
    <?php echo $__env->make('backend.common.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END Left Aside -->
        <div class="page-content-wrapper">
            <!-- BEGIN Page Header -->
        <?php echo $__env->make('backend.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END Page Header -->
            <!-- BEGIN Page Content -->
            <!-- the #js-page-content id is needed for some plugins to initialize -->
            <main id="js-page-content" role="main" class="page-content">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
            <!-- this overlay is activated only when mobile menu is triggered -->
            <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div> <!-- END Page Content -->
            <!-- BEGIN Page Footer -->
        <?php echo $__env->make('backend.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END Page Footer -->

        </div>
    </div>
</div>
<!-- END Page Wrapper -->
<!-- BEGIN Quick Menu -->
<!-- to add more items, please make sure to change the variable '$menu-items: number;' in your _page-components-shortcut.scss -->

<!-- END Quick Menu -->


<script src="<?php echo e(asset('backend/assets')); ?>/js/vendors.bundle.js"></script>
<script src="<?php echo e(asset('backend/assets')); ?>/js/app.bundle.js"></script>
<script src="<?php echo e(asset('backend/assets')); ?>/js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
<script src="<?php echo e(asset('backend/assets')); ?>/js/datagrid/datatables/datatables.bundle.js"></script>
<script src="<?php echo e(asset('backend/assets')); ?>/js/formplugins/select2/select2.bundle.js"></script>
<script src="<?php echo e(asset('backend/assets')); ?>/js/formplugins/summernote/summernote.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.1/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.6.8/axios.min.js"></script>
<!-- Jwt decode -->

<!-- <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script> -->

<script type="text/javascript">
    /* Activate smart panels */
    $('#js-page-content').smartPanel();
    $('.select2').select2();
    // axios.defaults.headers.common['Authorization'] = 'Bearer '+localStorage.getItem('access_token');

    
    
    
    
    
    

    
    
    
    
    
    

    // ====== JWT Token Checking ============= //
    
    
    

    
    

    

    
    
    
    
    
    
    
    
    
    
    
    // Example usage
    // const token = localStorage.getItem('access_token'); // Replace with the token you want to check
    // checkTokenExpiration(token);
    // console.log(token)

    // ====== JWT Token Checking ============= //

</script>
<?php echo $__env->yieldContent('js'); ?>


</body>
<!-- END Body -->
</html>
<?php /**PATH E:\Laravel Project\ecommerce\resources\views/backend/layout/app.blade.php ENDPATH**/ ?>