<textarea id="short_description" class="text-editor"></textarea>
<?php /**PATH E:\Laravel Project\ecommerce\resources\views/components/forms/shortdescription-editor.blade.php ENDPATH**/ ?>