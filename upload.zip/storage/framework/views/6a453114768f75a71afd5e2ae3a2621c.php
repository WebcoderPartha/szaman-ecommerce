<textarea id="description" class="text-editor"></textarea>
<?php /**PATH E:\Laravel Project\ecommerce\resources\views/components/forms/description-editor.blade.php ENDPATH**/ ?>