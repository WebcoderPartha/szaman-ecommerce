<?php $__env->startSection('title', 'Shipping Charge'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/inputTags.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <ol class="breadcrumb page-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('backend.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('backend.attribute.index')); ?>">Shipping Charge</a></li>
        <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
    </ol>

    <div class="row">
        <div class="col-xl-6">
            <div id="panel-5" class="panel py-2">
                <div class="panel-container show">
                    <div class="panel-content">
                        <div class="row">
                            <div class="col-md-12">

                                <h4> Shipping Charge</h4>
                                <form id="form" method="POST" action="<?php echo e(route('backend.shipping-charge.store')); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('POST'); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label" for="inside_dhaka">Inside Dhaka</label>
                                                <input class="form-control" id="inside_dhaka" value="<?php echo e(!empty($shipping_charge->inside_dhaka) ? $shipping_charge->inside_dhaka : ''); ?>" type="text" name="inside_dhaka">
                                                <?php $__errorArgs = ['inside_dhaka'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><small><?php echo e($message); ?></small></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label" for="outside_dhaka">Outside Dhaka</label>
                                                <input class="form-control" value="<?php echo e(!empty($shipping_charge->outside_dhaka) ? $shipping_charge->outside_dhaka : ''); ?>" id="outside_dhaka" type="text" name="outside_dhaka">
                                                <?php $__errorArgs = ['outside_dhaka'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><small><?php echo e($message); ?></small></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-4 text-right">
                                        <input type="hidden" value="<?php echo e(!empty($shipping_charge->id) ? $shipping_charge->id : ''); ?>" name="shipping_charge_id" id="shipping_charge_id">
                                        <button type="submit" id="form_button" class="btn btn-success">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('backend/assets/js/inputTags.jquery.min.js')); ?>"></script>
    <script>

        // Verify token
        
        
        

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Sweetalert
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
        });
        // Sweetalert

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


        

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Project\ecommerce\resources\views/backend/attribute/shipping-charge/index.blade.php ENDPATH**/ ?>