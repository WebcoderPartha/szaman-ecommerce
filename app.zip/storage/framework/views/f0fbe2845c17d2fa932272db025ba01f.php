<footer class="page-footer" role="contentinfo">
    <div class="d-flex align-items-center flex-1 text-muted">
        <span class="hidden-md-down fw-700"><?php echo e(date('Y')); ?> © e-Commerce by&nbsp;<span href='#' class='text-primary fw-500' >SZamanTech Team</span></span>
    </div>

</footer>
<?php /**PATH E:\Laravel Project\ecommerce\resources\views/backend/common/footer.blade.php ENDPATH**/ ?>