<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-12">
        <div class="hidden md:inline-block md:col-span-3 bg-white shadow-sm relative">
            <?php if (isset($component)) { $__componentOriginald41388bb996257058f43ae33ec151432 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald41388bb996257058f43ae33ec151432 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Home\DesktopMenu::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.home.desktop-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Home\DesktopMenu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald41388bb996257058f43ae33ec151432)): ?>
<?php $attributes = $__attributesOriginald41388bb996257058f43ae33ec151432; ?>
<?php unset($__attributesOriginald41388bb996257058f43ae33ec151432); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald41388bb996257058f43ae33ec151432)): ?>
<?php $component = $__componentOriginald41388bb996257058f43ae33ec151432; ?>
<?php unset($__componentOriginald41388bb996257058f43ae33ec151432); ?>
<?php endif; ?>
        </div>
        <div class="col-span-12 md:col-span-9">
            <?php if (isset($component)) { $__componentOriginal887098f63b4c4c268534b687e1d1a65e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal887098f63b4c4c268534b687e1d1a65e = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Home\SwiperSlider::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.home.swiper-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Home\SwiperSlider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal887098f63b4c4c268534b687e1d1a65e)): ?>
<?php $attributes = $__attributesOriginal887098f63b4c4c268534b687e1d1a65e; ?>
<?php unset($__attributesOriginal887098f63b4c4c268534b687e1d1a65e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal887098f63b4c4c268534b687e1d1a65e)): ?>
<?php $component = $__componentOriginal887098f63b4c4c268534b687e1d1a65e; ?>
<?php unset($__componentOriginal887098f63b4c4c268534b687e1d1a65e); ?>
<?php endif; ?>
        </div>
    </div>
    <div class="product-categories mt-4">
        <?php if (isset($component)) { $__componentOriginalaf77e3bfec1383ce5330aede0240e900 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaf77e3bfec1383ce5330aede0240e900 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Home\ProductCategories::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.home.product-categories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Home\ProductCategories::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaf77e3bfec1383ce5330aede0240e900)): ?>
<?php $attributes = $__attributesOriginalaf77e3bfec1383ce5330aede0240e900; ?>
<?php unset($__attributesOriginalaf77e3bfec1383ce5330aede0240e900); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaf77e3bfec1383ce5330aede0240e900)): ?>
<?php $component = $__componentOriginalaf77e3bfec1383ce5330aede0240e900; ?>
<?php unset($__componentOriginalaf77e3bfec1383ce5330aede0240e900); ?>
<?php endif; ?>
    </div>
    <div class="feature-products mt-4">
        <?php if (isset($component)) { $__componentOriginal06c99f7af25e44a704bdc73e8200b492 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06c99f7af25e44a704bdc73e8200b492 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Home\FeatureProducts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.home.feature-products'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Home\FeatureProducts::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06c99f7af25e44a704bdc73e8200b492)): ?>
<?php $attributes = $__attributesOriginal06c99f7af25e44a704bdc73e8200b492; ?>
<?php unset($__attributesOriginal06c99f7af25e44a704bdc73e8200b492); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06c99f7af25e44a704bdc73e8200b492)): ?>
<?php $component = $__componentOriginal06c99f7af25e44a704bdc73e8200b492; ?>
<?php unset($__componentOriginal06c99f7af25e44a704bdc73e8200b492); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Project\szaman-ecommerce\resources\views/frontend/homepage.blade.php ENDPATH**/ ?>