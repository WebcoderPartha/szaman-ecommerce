@extends('frontend.layout.app')


@section('content')
    <div class="grid grid-cols-12">
        <x-frontend.home.desktop-menu />
        <x-frontend.home.swiper-slider />
    </div>
@endsection

@section('js')

@endsection
