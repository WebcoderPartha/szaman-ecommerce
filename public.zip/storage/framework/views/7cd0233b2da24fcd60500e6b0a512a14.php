<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-12">
        <div class="hidden md:inline-block md:col-span-3 bg-white shadow-sm relative">
            <?php if (isset($component)) { $__componentOriginald41388bb996257058f43ae33ec151432 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald41388bb996257058f43ae33ec151432 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Home\DesktopMenu::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.home.desktop-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Home\DesktopMenu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald41388bb996257058f43ae33ec151432)): ?>
<?php $attributes = $__attributesOriginald41388bb996257058f43ae33ec151432; ?>
<?php unset($__attributesOriginald41388bb996257058f43ae33ec151432); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald41388bb996257058f43ae33ec151432)): ?>
<?php $component = $__componentOriginald41388bb996257058f43ae33ec151432; ?>
<?php unset($__componentOriginald41388bb996257058f43ae33ec151432); ?>
<?php endif; ?>
        </div>
        <div class="col-span-12 md:col-span-9">
            <!-- Swiper -->
            <div class="swiper bannerSwiper">
                <div class="swiper-wrapper">

                    <?php if($sliders->count() > 0): ?>
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <img src="<?php echo e(asset('/storage/slider/'.$slider->image)); ?>" alt="<?php echo e($slider->image); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="swiper-slide">
                            <img src="https://placehold.co/1921x581" alt="">
                        </div>
                    <?php endif; ?>

                </div>
                <div class="swiper-pagination"></div>
            </div>
            <!-- Swiper JS -->
        </div>
    </div>
    <div class="product-categories mt-4">
        <?php if (isset($component)) { $__componentOriginalaf77e3bfec1383ce5330aede0240e900 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaf77e3bfec1383ce5330aede0240e900 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Home\ProductCategories::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.home.product-categories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Home\ProductCategories::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaf77e3bfec1383ce5330aede0240e900)): ?>
<?php $attributes = $__attributesOriginalaf77e3bfec1383ce5330aede0240e900; ?>
<?php unset($__attributesOriginalaf77e3bfec1383ce5330aede0240e900); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaf77e3bfec1383ce5330aede0240e900)): ?>
<?php $component = $__componentOriginalaf77e3bfec1383ce5330aede0240e900; ?>
<?php unset($__componentOriginalaf77e3bfec1383ce5330aede0240e900); ?>
<?php endif; ?>
    </div>



    <?php echo $__env->make('frontend.partials.home.slider-category-products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Project\szaman-ecommerce\resources\views/frontend/homepage.blade.php ENDPATH**/ ?>