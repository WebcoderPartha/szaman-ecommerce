<?php $__env->startSection('title', 'Order Detail'); ?>
<?php $__env->startSection('content'); ?>

    <ol class="breadcrumb page-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('backend.dashboard')); ?>">Order</a></li>
        <li class="breadcrumb-item"> <?php echo e($order->order_number); ?></li>
        <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
    </ol>
    <div class="subheader">
        <h1 class="subheader-title">
            <small>
                Order Detail
            </small>
        </h1>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div id="panel-5" class="panel py-2">
                <div class="panel-container show">
                    <div class="panel-content">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="order_information">
                                    <div class="card">
                                        <div class="card-header bg-success">
                                            <h2 class="text-center mb-0 text-white">Order Information</h2>
                                        </div>
                                        <div class="card-body text-center">
                                            <div class="h5">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <td>Order ID</td>
                                                        <td><?php echo e($order->order_number); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Order Date</td>
                                                        <td><?php echo e(date('d-F-Y', strtotime($order->order_date))); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Transaction ID</td>
                                                        <td><?php echo e($order->tnx_id); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Payment Method</td>
                                                        <td><?php echo e($order->payment_method); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Payable Amount</td>
                                                        <td><?php echo e($order->payable_amount); ?> Taka</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Payment Status</td>
                                                        <td>
                                                            <?php if($order->payment_status == 1): ?>
                                                                <span class="badge badge-info">Paid</span>
                                                            <?php else: ?>
                                                                <span class="badge badge-warning">Unpaid</span>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="billing_information">
                                    <div class="card">
                                        <div class="card-header bg-success">
                                            <h2 class="text-center mb-0 text-white">Billing Information</h2>
                                        </div>
                                        <div class="card-body text-center">
                                            <div class="font-italic h4">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <td>Customer Name</td>
                                                        <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Phone</td>
                                                        <td><?php echo e($user->phone); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Email</td>
                                                        <td><?php echo e($user->email); ?></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="Shipping_information">
                                    <div class="card">
                                        <div class="card-header bg-success">
                                            <h2 class="text-center mb-0 text-white">Shipping Information</h2>
                                        </div>
                                        <div class="card-body text-center">
                                            <div class="font-italic h4">
                                                <?php echo e($order->shipping_address->address_line_one); ?>,<br>
                                                <?php echo e($order->shipping_address->post_office); ?>,  <?php echo e($order->shipping_address->thana); ?>, <br>
                                                <?php echo e($order->shipping_address->district); ?>-<?php echo e($order->shipping_address->postal_code); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12 mt-4">
                                <div class="order_items">
                                    <div class="card">
                                        <div class="card-header bg-success">
                                            <h2 class="text-center mb-0 text-white">Order Item List</h2>
                                        </div>
                                        <div class="card-body text-center">
                                            <table class="table table-bordered">
                                                <tr>
                                                    <th>SL</th>
                                                    <th>Image</th>
                                                    <th>Product Name</th>
                                                    <th>Price</th>
                                                    <th>Qty</th>
                                                    <th>Subtotal</th>
                                                </tr>
                                                <?php $__currentLoopData = $order->order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($key+1); ?></td>
                                                        <td><img src="<?php echo e(asset('/storage/product/'.$product->image)); ?>" width="50" alt=""></td>
                                                        <td><?php echo e($product->product_name); ?></td>
                                                        <td><?php echo e($product->price); ?></td>
                                                        <td><?php echo e($product->qty); ?></td>
                                                        <td><?php echo e($product->subtotal); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td colspan="5" class="text-right"><b>Shipping Charge</b></td>
                                                    <td><b><?php echo e($order->shipping_charge); ?>.00</b></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5" class="text-right"><b>Total</b></td>
                                                    <td><b><?php echo e($order->payable_amount); ?> Taka</b></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>




    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Project\szaman-ecommerce\resources\views/backend/order/order-view.blade.php ENDPATH**/ ?>