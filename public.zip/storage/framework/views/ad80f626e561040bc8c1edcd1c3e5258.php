<?php $__env->startSection('title', 'SSLCommerz Credentials'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/inputTags.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <ol class="breadcrumb page-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('backend.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('backend.attribute.index')); ?>">SSLCommerz</a></li>
        <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
    </ol>

    <div class="row">
        <div class="col-xl-12">
            <div id="panel-5" class="panel py-2">
                <div class="panel-container show">
                    <div class="panel-content">
                        <div class="row">
                            <div class="col-md-12">
                                <h4> SSLCommerz Credentials</h4>
                                <form id="form" method="POST" action="<?php echo e(route('backend.setting.sslcommerz.store')); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('POST'); ?>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="form-label" for="store_id">Store ID</label>
                                                <input class="form-control" id="store_id" value="<?php echo e(!empty($sslcommerz->store_id) ? $sslcommerz->store_id : ''); ?>" placeholder="Enter store id" type="password" name="store_id">
                                                <?php $__errorArgs = ['store_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><small><?php echo e($message); ?></small></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="form-label" for="store_password">Store Password</label>
                                                <input class="form-control" value="<?php echo e(!empty($sslcommerz->store_password) ? $sslcommerz->store_password : ''); ?>" placeholder="Store password" id="store_password" type="password" name="store_password">
                                                <?php $__errorArgs = ['store_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><small><?php echo e($message); ?></small></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="form-label" for="is_live">Sandbox</label>
                                                <select class="form-control select2" name="is_live" id="is_live">
                                                    <option value="">---Select---</option>
                                                    <option value="0" <?php if(isset($sslcommerz->is_live) && $sslcommerz->is_live == 0): ?> selected <?php endif; ?>>Test Mode</option>
                                                    <option value="1" <?php if(isset($sslcommerz->is_live) && $sslcommerz->is_live == 1): ?> selected <?php endif; ?>>Live</option>
                                                </select>
                                                <?php $__errorArgs = ['is_live'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><small><?php echo e($message); ?></small></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-4 text-right">
                                        <button type="submit" id="form_button" class="btn btn-success">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Project\szaman-ecommerce\resources\views/backend/setting/sslcommerz.blade.php ENDPATH**/ ?>