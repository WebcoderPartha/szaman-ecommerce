<?php $__env->startSection('title', 'Profile | My Account'); ?>
<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-12 py-4 gap-6">
        <div class="col-span-12">
            <h2 class="font-semibold">My Account</h2>
        </div>
        <div class="col-span-12 md:col-span-3 border border-gray-300 rounded">
            <div class="flex flex-col gap-4 py-4">
                <div class="profile">
                    <div class="profile_pic_content flex flex-col justify-center items-center gap-3">
                        <div class="profile_pic">
                            <img src="https://mohasagor.com/public/frontend/images/user/1.png" alt="" width="150">
                        </div>
                        <div class="profile_name">
                            <h5 class="text-xl text-[#323232] font-semibold"><?php echo e(auth('web')->user()->first_name); ?> <?php echo e(auth('web')->user()->last_name); ?></h5>
                        </div>
                    </div>
                </div>
                <div class="menu-list ">
                    <ul class="px-4 py-2">
                        <li class="border-b border-b-[#ced4da]">
                            <a href="<?php echo e(route('frontend.myaccount.page')); ?>" class="<?php if(request()->is('my-account')): ?> text-theme <?php endif; ?> py-2 text-sm uppercase block hover:text-theme">
                                <i class="fa-solid fa-table-cells-large mr-1"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="border-b border-b-[#ced4da]">
                            <a href="<?php echo e(route('frontend.myaccount.view_profile')); ?>" class="<?php if(request()->is('my-account/profile')): ?> text-theme <?php endif; ?> py-2 text-sm uppercase block hover:text-theme ">
                                <i class="fa-regular fa-user mr-1"></i>
                                Profile
                            </a>
                        </li>
                        <li class="border-b border-b-[#ced4da]">
                            <a href="<?php echo e(route('frontend.myaccount.view_profile.edit')); ?>" class="<?php if(request()->is('my-account/profile/edit')): ?> text-theme <?php endif; ?> py-2 text-sm uppercase block hover:text-theme">
                                <i class="fa-regular fa-pen-to-square mr-1"></i>
                                Edit Profile
                            </a>
                        </li>
                        <li class="border-b border-b-[#ced4da]">
                            <a href="<?php echo e(route('frontend.myaccount.address.view')); ?>" class="<?php if(request()->is('my-account/address')): ?> text-theme <?php endif; ?> py-2 text-sm uppercase block hover:text-theme">
                                <i class="fa-solid fa-location-dot mr-1"></i>
                                Address
                            </a>
                        </li>
                        <li class="border-b border-b-[#ced4da]">
                            <a href="<?php echo e(route('frontend.myaccount.change_password')); ?>" class="<?php if(request()->is('my-account/change-password')): ?> text-theme <?php endif; ?> py-2 text-sm uppercase block hover:text-theme">
                                <i class="fa-solid fa-key mr-1"></i>
                                Change Password
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('customer.logout')); ?>" class="py-2 text-sm uppercase block hover:text-theme">
                                <i class="fa-solid fa-right-from-bracket mr-1"></i>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-span-12 md:col-span-9 border border-gray-300">

            <div class="profile_heading text-center py-4">
                <h3 class="text-2xl font-semibold">Profile</h3>
            </div>
            <div class="table-responsive px-4">

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Project\szaman-ecommerce\resources\views/frontend/my-account/profile.blade.php ENDPATH**/ ?>