
<!-- Swiper -->

    <div class="swiper bannerSwiper">
        <div class="swiper-wrapper">

            <?php if($sliders->count() > 0): ?>
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <img src="<?php echo e(asset('/storage/slider/'.$slider->image)); ?>" alt="<?php echo e($slider->image); ?>">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="swiper-slide">
                    <img src="https://placehold.co/1921x581" alt="">
                </div>
            <?php endif; ?>

        </div>
        <div class="swiper-pagination"></div>
    </div>
<!-- Swiper JS -->

<?php $__env->startSection('js'); ?>

    <script>
        let swiper = new Swiper(".bannerSwiper", {
            spaceBetween: 30,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH E:\Laravel Project\szaman-ecommerce\resources\views/components/frontend/home/swiper-slider.blade.php ENDPATH**/ ?>