<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<!-- Swiper -->

<!-- Swiper -->
<div class="swiper mySwiper">
    <div class="swiper-wrapper">
        <div class="swiper-slide">Slide 1</div>
        <div class="swiper-slide">Slide 2</div>
        <div class="swiper-slide">Slide 3</div>
        <div class="swiper-slide">Slide 4</div>
        <div class="swiper-slide">Slide 5</div>
        <div class="swiper-slide">Slide 6</div>
        <div class="swiper-slide">Slide 7</div>
        <div class="swiper-slide">Slide 8</div>
        <div class="swiper-slide">Slide 9</div>
    </div>
    <div class="swiper-pagination"></div>
</div>
<!-- Swiper JS -->

<?php $__env->startSection('js'); ?>
    <!-- Swiper JS -->

<?php $__env->stopSection(); ?>
<?php /**PATH E:\Laravel Project\szaman-ecommerce\resources\views/components/frontend/home/category-wish-product.blade.php ENDPATH**/ ?>