<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>
        Login | e-Commerce
    </title>
    <meta name="description" content="Login">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no, minimal-ui">
    <!-- Call App Mode on ios devices -->
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <!-- Remove Tap Highlight on Windows Phone IE -->
    <meta name="msapplication-tap-highlight" content="no">
    <!-- base css -->
    <link id="vendorsbundle" rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets/css/vendors.bundle.css')); ?>">
    <link id="appbundle" rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets/css/app.bundle.css')); ?>">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets')); ?>/css/notifications/sweetalert2/sweetalert2.bundle.css">
    <link id="mytheme" rel="stylesheet" media="screen, print" href="#">
    <link id="myskin" rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets/css/skins/skin-master.css')); ?>">
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('backend/assets/img/favicon/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('backend/assets/img/favicon/favicon-32x32.png')); ?>">
    <link rel="mask-icon" href="<?php echo e(asset('backend/assets/img/favicon/safari-pinned-tab.svg')); ?>" color="#5bbad5">
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/assets/css/page-login-alt.css')); ?>">
</head>

<body>

<div class="blankpage-form-field">
    <div class="" style="background: #886ab5">
        <h2 class="text-center py-2 p-0 text-white">

            Ecommerce
        </h2>
    </div>
    <div class="card p-4 border-top-left-radius-0 border-top-right-radius-0">
        <form action="<?php echo e(route('admin.login')); ?>" method="post">

            <?php echo csrf_field(); ?> <?php echo method_field('POST'); ?>
            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block text-danger">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block text-danger">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="text-center">
                <button id="login_button" type="submit" class="btn btn-primary">Login</button>
            </div>
        </form>
    </div>

</div>





<script src="<?php echo e(asset('backend/assets/js/vendors.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/app.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets')); ?>/js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
<script>
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


    
    
    



</script>
<!-- Page related scripts -->
</body>
<!-- END Body -->
</html>
<?php /**PATH E:\Laravel Project\szaman-ecommerce\resources\views/backend/auth/login.blade.php ENDPATH**/ ?>